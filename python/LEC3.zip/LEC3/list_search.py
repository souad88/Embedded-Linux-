
#mylist1=[3,4,1,2,7,8,111,0]
mylist=[355,4,1,26,7,8,11,40]
#sort Ascending
mylist.sort()
print(mylist)
#sort Descending
mylist.sort(reverse=True)
print(mylist) #reverse sorting numbers
