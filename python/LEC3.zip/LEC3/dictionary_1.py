mydict={"saturday":"Sporting day",
        "Sunday":"revesion",
        "date":"20/8/2023" }
#loop Methods :
for x in mydict:
    print(x)

for x in mydict.values():
    print(x)    
 
if "saturday" in mydict:
    print("Y")    