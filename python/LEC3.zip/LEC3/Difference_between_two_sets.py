set1={"h","j","k","G","p"}
set2={"h","J","n","G","m"}
difference_=set1.difference(set2)
print(difference_)
