#list as stack
stack=[1,2,3,4]
stack.append("ddd") #Push 
stack.append("hi")
print(stack)
stack.pop()
print(stack)