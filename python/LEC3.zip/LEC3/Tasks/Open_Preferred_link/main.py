#show preffered  websits link for the user 
#ask the user to choose one of them
#open the choosed one
#hint use :firelink,webbrowser 
import preferred_links

print("Your Preferred Links are :")
preferred_links.show_links()
