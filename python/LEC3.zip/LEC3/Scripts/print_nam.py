import pyfiglet
myname=pyfiglet.figlet_format("Souaad")
print(myname)
#alia