set1={"h","j","k","G","p"}
set2={"h","J","n","G","m"}
Intersections_=set1.intersection(set2)
print(Intersections_)