import datetime
dateNOW=datetime.datetime.now()
print(dateNOW.year)
print(dateNOW.strftime("%A"))
print(dateNOW.strftime("%Y %B %d"))

