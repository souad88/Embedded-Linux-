import utils.util as myfunctions
print(__name__) #defines you as a main function when you run this file