import run

def tool():
    print("Vs-Code")

#How to put an Entry point to your Code
def main():
    print("Entery Point")
if __name__=="__main__": #if you are in the main (where you run file)then excute function main()
    main()    