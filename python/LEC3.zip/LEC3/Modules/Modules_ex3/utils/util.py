def hello():
    print("Hello")
    