def tool_1():
    print("Vs Code")
def tool_2():
    print("Git-Hub")   
def module2_nam():
    print(__name__)        