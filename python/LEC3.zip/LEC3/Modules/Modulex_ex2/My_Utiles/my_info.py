def my_name(nam):
    print(nam)
def my_age(ag):
    print(ag)
def course_nam(nm):
    print(nm)    
def module1_nam():
    print(__name__)        