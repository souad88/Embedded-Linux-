#Tree of folders
#from My_Utiles import *  --> import all files in Folder
from My_Utiles import my_info
from My_Utiles import tools

my_info.module1_nam()
my_info.my_name("Souad")
my_info.my_age(35)
my_info.course_nam("Embedded Linux")
tools.module2_nam()
tools.tool_1()
tools.tool_2()
