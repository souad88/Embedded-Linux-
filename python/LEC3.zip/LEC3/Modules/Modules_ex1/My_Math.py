def sum(x,y):
    return x+y
def sub(x,y):
    return x-y
def name_module():
    #print variables(built_in variables) of modules ..name of the module , doc if it exist
   print(__name__)
   print(__doc__)