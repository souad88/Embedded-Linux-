import My_Math
My_Math.name_module()
print(My_Math.sum(3,4))
print(My_Math.sub(4,4))
