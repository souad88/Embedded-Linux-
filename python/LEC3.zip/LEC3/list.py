mylist=[1,2,3,4,5,6,7,"LIST"]
if "LIS" in mylist:
    print("yes")
else :
    print("No")   
mylist[0:3]=["A","B"]
print(mylist)    