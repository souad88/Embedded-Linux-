
Course_1={"day":"Monday","name":"Python"}
Course_2={"day":"Thursday","course ":"C++"}
    
Next_courses_details={
    "course 1":Course_1,
    "course 2" :Course_2
    
}
print(Next_courses_details)