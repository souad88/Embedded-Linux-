

#Assum info.txt is in the Current folder in
#python_code 
#open and read file
f=open("info.txt",) #equal to f=open("file.txt","rt")
print(f.read())