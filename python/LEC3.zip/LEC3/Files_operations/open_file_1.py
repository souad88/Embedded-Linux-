
#f = open("D:\\myfiles\welcome.txt", "r")
f=open("/home/souad/Desktop/GitHub_/Embedded-Linux-/python/LEC3/x.txt","r")
print(f.read()) 