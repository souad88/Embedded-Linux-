#Hint:switch to Ubuntu Xorg
import pyautogui
import time
import os
print(__file__)
print(os.path.dirname(os.path.realpath(__file__)))
print(os.getcwd()) #getcwd : get current working directory