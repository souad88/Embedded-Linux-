import pyautogui #control windows &mouse
while True :
    x,y=pyautogui.position() #find cursor Position 
    print(x,y) 