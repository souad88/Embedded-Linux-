import pyautogui
import time

pyautogui.alert('This is an alert box.') #it will open an alert window 